    public class Conta {
        private int numeroConta;
        private String nomeCliente;
        private double saldo;

        public Conta(int numeroConta, String nomeCliente, double saldo) {
            this.numeroConta = numeroConta;
            this.nomeCliente = nomeCliente;
            this.saldo = saldo;

        }
        
        public void depositar(double valor) {
            saldo += valor;
        }

        public void sacar(double valor) {
            if (saldo >= valor) {
                saldo -= valor;
            } else {
                System.out.println("Saldo insuficiente.");
            }
        }

    }


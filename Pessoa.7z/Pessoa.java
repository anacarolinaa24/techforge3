import java.time.LocalDate;

class Universidade {
    private final String nome;

    public Universidade(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}

class Pessoa {
    private final String nome;
    private final LocalDate dataNascimento;
    private final Universidade universidade;

    public Pessoa(String nome, LocalDate dataNascimento, Universidade universidade) {
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.universidade = universidade;
    }

    public void mostrarInformacoes() {
        System.out.println(nome + " nasceu em " + dataNascimento + " e trabalhou na universidade " + universidade.getNome());
    }
}

class Main {
    public static void main(String[] args) {
        // Criando as universidades
        Universidade princeton = new Universidade("Princeton");
        Universidade cambridge = new Universidade("Cambridge");

        // Criando as pessoas
        Pessoa einstein = new Pessoa("Albert Einstein", LocalDate.of(1879, 3, 14), princeton);
        Pessoa newton = new Pessoa("Isaac Newton", LocalDate.of(1643, 1, 4), cambridge);

        // Mostrando as informações
        einstein.mostrarInformacoes();
        newton.mostrarInformacoes();
    }
}